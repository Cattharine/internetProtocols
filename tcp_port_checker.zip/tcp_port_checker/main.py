import socket


class Checker:
    def __init__(self):
        try:
            print("start:")
            self.start = int(input())
            print("end:")
            self.end = int(input())
        except:
            print("Something went wrong :(")
            print("Your input is wrong.")
            print("It should be two integers in two different lines")
            print("For example:")
            print("start:")
            print("80")
            print("end:")
            print("100")

        print("please, wait, program is working. It can take some time")

        for i in range(self.start, self.end + 1):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                c = sock.connect_ex(("localhost", i))
                if not c:
                    print(f"this port is open: {i}")


if __name__ == "__main__":
    Checker()
