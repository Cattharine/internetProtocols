from dnslib.dns import *
import socket
import argparse
import sys

HOST = "localhost"
PORT = 53


def __main__(q_name, q_type):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        c = client.connect_ex((HOST, PORT))
        while c:
            c = client.connect_ex((HOST, PORT))
        question = DNSRecord.question(q_name, q_type).pack()
        client.send(question)
        answer = DNSRecord.parse(client.recv(2048))
        if answer.header.rcode == 2:
            print("Server is not available")
        else:
            if len(answer.auth) > 0 or answer.header.rcode == 1:
                print("There was a mistake in your request. Please try again")
            else:
                print(answer)


if __name__ == "__main__":
    argv = sys.argv[1:]
    if argv:
        parser = argparse.ArgumentParser()
        parser.add_argument('-t', '--type', action="store", default="A",
                            choices=["NS", "PTR", "A", "AAAA"], help="type of recording")
        parser.add_argument('qname')
        args = parser.parse_args(argv)
        __main__(args.qname, args.type)
    else:
        __main__("93.88.176.11", "PTR")
