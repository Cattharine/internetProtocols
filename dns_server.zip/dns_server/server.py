from dnslib.dns import *
import socket
from time import time as time_s
import json
import os


class Server:
    HOST = "8.8.8.8"
    PORT = 53

    def __init__(self):
        # {q_name: {q_type: (ttl, [rr], auth, [additional])}}
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "cache.txt"), encoding="cp1251") as cache:
            f = cache.read()
            self.cache = json.loads(f)

        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
            server.bind(("", Server.PORT))
            self.work_loop(server)

    def work_loop(self, server):
        while 1:
            data, addr = server.recvfrom(2048)
            data = self.get_answer(data)
            server.sendto(data, addr)

    def require(self, query):
        q_name, q_type = self.parse_name_and_type(DNSRecord.parse(query))
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
            client.settimeout(2)
            try:
                c = client.connect_ex((Server.HOST, Server.PORT))
                while c:
                    c = client.connect_ex((Server.HOST, Server.PORT))
                client.send(DNSRecord.question(q_name, q_type).pack())
                data = client.recv(2048)
                if q_type == "NS":
                    try:
                        answer = str(DNSRecord.parse(data).a).split()[-1]
                        next_query = DNSRecord.question(answer).pack()
                        client.send(next_query)
                        next_data = client.recv(2048)
                        answer = str(DNSRecord.parse(next_data).a).split()[-1]
                        c = client.connect_ex((answer, Server.PORT))
                        while c:
                            c = client.connect_ex((answer, Server.PORT))
                        client.send(query)
                        data = client.recv(2048)
                    except OSError:
                        query = DNSRecord.parse(query)
                        query.header.rcode = 2
                        print("no answer from server")
                        return query.pack()
                self.add_recording(q_name, q_type, data)
                return data
            except OSError:
                query = DNSRecord.parse(query)
                query.header.rcode = 2
                print("no answer from server")
                return query.pack()

    def add_recording(self, q_name, q_type, data):
        answer = DNSRecord.parse(data)
        s_answer = str(answer)
        main = s_answer.split("ANSWER SECTION:\n")
        if len(main) < 2:
            return
        main = main[1].split('\n', int(answer.header.a))[:int(answer.header.a)]
        additional = s_answer.split("ADDITIONAL SECTION:\n")
        if len(additional) < 2:
            additional = []
        else:
            additional = additional[1].split('\n', int(answer.header.ar))[:int(answer.header.ar)]
        ttl = min([int(r.split()[1]) for r in main] + [int(r.split()[1]) for r in additional])
        auth = answer.header.aa
        if q_name not in self.cache:
            self.cache[q_name] = {}
        self.cache[q_name][q_type] = (int(time_s()) + ttl, main, auth, additional)
        print("nothing was in cache")
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "cache.txt"), mode="w", encoding="cp1251") as cache:
            cache.write(json.dumps(self.cache))

    def get_answer(self, data):
        query = DNSRecord.parse(data)
        res = self.search_in_cache(query)
        if res is not None:
            print("from cache")
            answer = query.reply(aa=res[-1])
            for a in res[0]:
                answer.add_answer(*RR.fromZone(a))
            for a in res[1]:
                answer.add_ar(*RR.fromZone(a))
            return answer.pack()
        return self.require(data)

    def search_in_cache(self, query):
        q_name, q_type = self.parse_name_and_type(query)
        self.clean_cache()
        if q_name in self.cache and q_type in self.cache[q_name]:
            answer = self.cache[q_name][q_type][1]
            additional = self.cache[q_name][q_type][-1]
            return answer, additional, self.cache[q_name][q_type][2]

    def parse_name_and_type(self, query):
        q = str(query).split("QUESTION SECTION:\n")[1].split('\n')[0].split()
        if q[0].endswith(".in-addr.arpa"):
            return q[0][1:], q[-1]
        elif q[-1] == "PTR":
            q_name = '.'.join(reversed(q[0][1:].split('.'))) + ".in-addr.arpa"
            return q_name[1:], q[-1]
        if q[0].endswith("."):
            return q[0][1:], q[-1]
        else:
            return q[0][1:] + '.', q[-1]

    def clean_cache(self):
        new_cache = {}
        for q_name in self.cache:
            for q_type in self.cache[q_name]:
                t = int(time_s())
                if self.cache[q_name][q_type][0] > t:
                    if q_name not in new_cache:
                        new_cache[q_name] = {}
                    new_cache[q_name][q_type] = self.cache[q_name][q_type]
        self.cache = new_cache


if __name__ == "__main__":
    Server()
