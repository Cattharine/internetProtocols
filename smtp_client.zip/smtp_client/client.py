import socket
import ssl
import base64
import message_creator as MC
import config_reader as CR


class Client:
    HOST = "smtp.yandex.ru"
    PORT = 465
    LOGIN = 'catherine.vasilko@yandex.ru'
    PASS = 'ehmjinxivcniislr'

    def __init__(self, message, to):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.connect((Client.HOST, Client.PORT))
            client = ssl.wrap_socket(client)
            client.recv(1024)
            self.send_msg(client, message, to)

    def send_msg(self, client, message, to):
        self.greet(client)
        self.send(client, f"MAIL FROM:{Client.LOGIN}\n".encode())
        for rec in to:
            self.send(client, f"RCPT TO:{rec}\n".encode())
        self.send(client, "DATA\n".encode())
        for line in message:
            client.send((line + "\n").encode())
        self.send(client, "QUIT\n".encode())

    def greet(self, client):
        base64_login = base64.b64encode(Client.LOGIN.encode()).decode()
        base64_pass = base64.b64encode(Client.PASS.encode()).decode()
        self.send(client, 'EHLO smtp_client\n'.encode())
        self.send(client, 'AUTH LOGIN\n'.encode())
        self.send(client, (base64_login + '\n').encode())
        self.send(client, (base64_pass + '\n').encode())

    def send(self, client, line):
        client.send(line)
        print(client.recv(2048).decode())


if __name__ == "__main__":
    conf = CR.ConfigReader()
    mc = MC.MessageCreator(conf)
    Client(mc.message, conf.recs)
