import os


class ConfigReader:
    def __init__(self):
        self.path = os.path.dirname(os.path.abspath(__file__))
        self.recs = []
        self.theme = ""
        self.attachments = []
        with open(os.path.join(self.path, 'msg', 'config.txt'), mode="r", encoding="utf8") as conf:
            lines = conf.readlines()
            for line in lines:
                line = line.strip('\ufeff\n')
                if line.startswith("RCPT"):
                    self.recs = [l.replace(',', '') for l in line.split()[1:]]
                elif line.startswith("THEME"):
                    self.theme = " ".join(line.split()[1:])
                elif line.startswith("ATTACH"):
                    line = line.replace("ATTACH ", "")
                    self.attachments = line.split(", ")
                    if len(self.attachments) == 1 and self.attachments[0] == "":
                        self.attachments = []
