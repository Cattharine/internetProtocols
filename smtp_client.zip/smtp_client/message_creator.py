import base64
import email.utils
from os import path


class MessageCreator:
    def __init__(self, conf):
        self.time = email.utils.localtime()
        self.text = ''
        with open(path.join(conf.path, "msg", "text.txt"), mode="r", encoding="utf-8") as text:
            self.text = text.readlines()
        self.text = [line.lstrip('\ufeff')
                     if not self.only_dots_in_line(line)
                     else '.' + line.lstrip('ufeff') for line in self.text]
        self.text = ''.join(self.text)
        self.text = base64.b64encode(self.text.encode()).decode()
        boundary = self.create_boundary()
        self.message = []
        self.message.append('From: catherine.vasilko@yandex.ru')
        self.message.append(f"To: {','.join(conf.recs)}")
        self.message.append(
            f"Subject: =?UTF-8?B?{base64.b64encode(conf.theme.encode()).decode()}?=")
        self.message.append("MIME-Version: 1.0")
        self.message.append(f"Date: {self.time}")
        if conf.attachments:
            self.message.append(f"Content-Type: multipart/mixed; boundary=\"{boundary}\"")
            self.message.append("\n")
            self.message.append(f"--{boundary}")
            self.message.append("Content-Type: text/plain; charset=utf-8")
            self.message.append(f"Content-Transfer-Encoding: base64\n")
            self.message.append(self.text)
            for attach in conf.attachments:
                with open(path.join(conf.path, "msg", attach), mode="rb") as file:
                    attachment = file.read()
                attachment = base64.b64encode(attachment).decode()
                attach_64 = base64.b64encode(attach.encode()).decode()
                self.message.append(f'--{boundary}')
                self.message.append(f"Content-Type: {self.get_type(attach)}; " +
                                    f"name=\"=?UTF-8?B?{attach_64}?=\"")
                self.message.append(f"Content-Disposition: attachment; " +
                                    f"filename=\"=?UTF-8?B?{attach_64}?=\"")
                self.message.append("Content-Transfer-Encoding: base64\n")
                self.message.append(attachment)
            self.message.append(f"--{boundary}--")
        else:
            self.message.append("Content-Type: text/plain; charset=utf-8")
            self.message.append(f"Content-Transfer-Encoding: base64\n")
            self.message.append(self.text)
        self.message.append('\n.')

    def only_dots_in_line(self, line):
        for i in range(len(line)):
            if i == len(line) - 1:
                continue
            if line[i] != '.' or line[i] != '\ufeff':
                return False
        return True

    def get_type(self, name):
        c_type = name.split('.')[-1]
        if c_type == 'jpeg' or c_type == 'jpg' or c_type == 'png' or c_type == 'gif':
            return f"image/{c_type}"
        elif c_type == 'mp3':
            return f"audio/{c_type}"
        elif c_type == 'mp4':
            return f'video/{c_type}'
        else:
            return f'application/{c_type}'

    def create_boundary(self):
        return str(hash(self.time))
