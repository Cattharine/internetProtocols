import socket
import ssl
import sys
import email
import argparse
import mail_parser
import saver as s


class Client:
    COMMANDS = {'1': 'TOP',
                '2': 'RETR'}

    SERVERS = {"yandex.ru": 'pop.yandex.ru',
               "mail.ru": 'pop.mail.ru'}

    PORT = 995

    def __init__(self, server, login, password):
        server = socket.gethostbyname(self.SERVERS[server])
        self.login = login
        self.password = password

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.connect((server, self.PORT))
            self.client = ssl.wrap_socket(client)
            success, _ = self.connected_successfully()
            if success:
                print("Connected")
                success = self.authorize()
                if success:
                    self.work_loop()
                else:
                    print("Ошибка при авторизации")
            else:
                print("Что-то пошло не так. Попробуйте позже")

    def connected_successfully(self):
        data = self.client.recv(1024).decode('ascii')
        ok = data.startswith('+OK')
        return ok, data

    def send_command(self, command):
        self.client.send(f'{command}\r\n'.encode())
        ok, data = self.connected_successfully()
        if not ok:
            print(f'Ошибка выполнения команды {command}, ответ: {data}')
        return ok, data

    def print_commands(self):
        print('Команды:')
        print("Вывести список команд:")
        print("Формат: -")
        print('Закончить сеанс и выйти из приложения:')
        print('Формат: 0')
        print('Посмотреть заголовок и несколько первых строк сообщения:')
        print('Формат: 1 <номер сообщения> <количество строк>')
        print('Скачать письмо:')
        print('Формат: 2 <номер сообщения>')

    def get_number_of_messages(self):
        _, data = self.send_command('STAT')
        count = data.split()[1]
        return count

    def execute_command(self, command):
        split = command.split()
        command_number = split[0]
        if command_number == '-' or command_number == '0':
            self.perform_command(command_number)
        elif command_number not in self.COMMANDS:
            print('Такой команды, к сожалению, нет')
        else:
            full_command = f'{self.COMMANDS[command_number]} {" ".join(split[1:])}'
            ok, _ = self.send_command(full_command)
            if ok:
                self.perform_command(command_number)

    def download_message(self):
        message = self.read_message()
        decoded = str(email.message_from_bytes(message))
        parsed = mail_parser.parse_message(decoded)
        printable = mail_parser.get_printable(parsed)
        s.Saver().save_message(parsed, printable)

    def read_message(self):
        message = b''
        while not message.endswith(b'\r\n.\r\n'):
            data = self.client.recv(2048)
            message += data
        return message

    def print_top(self):
        message = self.read_message()
        decoded = str(email.message_from_bytes(message))
        parsed = mail_parser.parse_message(decoded)
        printable = mail_parser.get_printable(parsed)
        print(printable)

    def perform_command(self, command):
        if command == '-':
            self.print_commands()
        elif command == '0':
            print('Завершение работы программы')
            sys.exit()
        elif command == '1':
            print('Ваши данные: ')
            self.print_top()
        elif command == '2':
            print('Загрузка сообщения в папку messages')
            self.download_message()
            print("Сообщение было успешно загружено")

    def work_loop(self):
        self.print_commands()
        while True:
            message_count = self.get_number_of_messages()
            print(f'Доступно {message_count} сообщений.')
            command = input('Введите команду:')
            self.execute_command(command)

    def authorize(self):
        self.send_command(f'USER {self.login}')
        success, _ = self.send_command(f'PASS {self.password}')
        return success


def __main__():
    argv = sys.argv[1:]
    argparser = argparse.ArgumentParser()
    argparser.add_argument('-ms', '--mail_server', action="store",
                           choices=["yandex.ru", "mail.ru"], help="your mail server")
    args = argparser.parse_args(argv)
    if args.mail_server:
        login = input('Логин: ')
        password = input('Пароль: ')
        Client(args.mail_server, login, password)
    else:
        print("Способ использования:")
        print("client.py -h")


if __name__ == "__main__":
    __main__()
