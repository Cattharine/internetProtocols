import os


class Saver:
    def __init__(self):
        self.path = os.path.dirname(os.path.abspath(__file__))

    def create_dir(self, subject, counter="(1)"):
        if not os.path.exists(os.path.join(self.path, 'messages', subject)):
            os.mkdir(os.path.join(self.path, 'messages', subject))
            return subject
        elif not os.path.exists(os.path.join(self.path, 'messages', subject + counter)):
            os.mkdir(os.path.join(self.path, 'messages', subject + counter))
            return subject + counter
        else:
            subject = self.create_dir(subject, f"({int(counter[1:len(counter) - 1]) + 1})")
            return subject

    def save_message(self, parsed, printable):
        subject = parsed['subject']
        subject = self.create_dir(subject)
        with open(os.path.join(self.path, 'messages', subject, f'{subject}.txt'), 'w') as f:
            f.write(printable)
        for content in parsed['contents']:
            self.save_content(content, subject)

    def save_content(self, content, subject):
        content_type = content['type']
        encoding = content['encoding']
        if content_type.startswith('text'):
            content_save = content['content'].decode(encoding)
            with open(os.path.join(self.path, 'messages', subject, "message.txt"), 'w',
                      encoding=encoding) as f:
                f.write(content_save)
        else:
            if content['filename']:
                filename = content['filename']
                with open(os.path.join(self.path, 'messages', subject, filename), 'wb') as f:
                    f.write(content['content'])