import base64
import quopri
import re

RE_ENCODED = re.compile(r'.*?\?(.*?)\?(.?)\?(.*?)\?.*? <(.*?)>')
FROM_RE = re.compile(r'From: (.*?)\n')
TO_RE = re.compile(r'To: (.*?)\n')
BOUNDARY_RE = re.compile(r'boundary="(.*?)"')

CONTENT_TRANSFER_ENCODINGS = {'quoted-printable': quopri.decodestring,
                              'base64': base64.decodebytes,
                              '7bit': quopri.decodestring}

SUBJECT_RE = re.compile(r' =\?(.*?)\?=\n')
CONTENT_TYPE_RE = re.compile(r'Content-Type: (.*?)[\n;]')
CHARSET_RE = re.compile(r'charset="(.*?)"')
FILENAME_RE = re.compile(r'filename="=\?(.*?)\?="')
CONTENT_TRANSFER_ENCODING_RE = re.compile(r'Content-Transfer-Encoding: (.*)[\n;]')
CONTENT_RE = re.compile(r'\n\n(.*)', re.DOTALL)
SUBJECT_TYPE_ENCODINGS = {'q': quopri.decodestring,
                          'b': base64.decodebytes}


def parse_attach(part):
    content_type = re.findall(CONTENT_TYPE_RE, part)[0]
    if content_type.startswith('multipart'):
        return parse_contents(part)
    charset = re.findall(CHARSET_RE, part)
    content_transfer_encoding = re.findall(CONTENT_TRANSFER_ENCODING_RE, part)
    content = re.findall(CONTENT_RE, part)[0].encode()
    filename_re = re.findall(FILENAME_RE, part)
    if content_transfer_encoding:
        content = CONTENT_TRANSFER_ENCODINGS[content_transfer_encoding[0]](
            content)
        content_transfer_encoding = content_transfer_encoding[0]
    if charset:
        encoding = charset[0]
    else:
        encoding = 'utf-8'
    if not content_type.startswith('text'):
        filename = parse_encoded_subject(filename_re)
    else:
        filename = None
    return {'type': content_type,
            'transfer_encoding': content_transfer_encoding,
            'content': content,
            'encoding': encoding,
            'filename': filename}


def parse_contents(message):
    boundary = '--' + re.search(BOUNDARY_RE, message)[1]
    parts = message.split(boundary)[1:-1]
    parsed_parts = []
    for part in parts:
        parsed = parse_attach(part)
        if type(parsed) is list:
            for parsed_part in parsed:
                parsed_parts.append(parsed_part)
        else:
            parsed_parts.append(parsed)
    return parsed_parts


def parse_encoded_header(header, regexp):
    header = re.findall(regexp, header)[0]
    encoding = header[0]
    transfer_encoding = header[1].lower()
    encoded = header[2]
    transfer_encoding = SUBJECT_TYPE_ENCODINGS[transfer_encoding]
    decoded = transfer_encoding(encoded.encode()).decode(encoding)
    return decoded, header


def parse_encoded_subject(header):
    res = ''
    for line in header:
        part = line.split('?')
        encoding = part[0]
        transfer_encoding = part[1].lower()
        encoded = part[2]
        transfer_encoding = SUBJECT_TYPE_ENCODINGS[transfer_encoding]
        decoded = transfer_encoding(encoded.encode()).decode(encoding)
        res += decoded
    return res


def parse_message(message):
    h_from, to, subject = parse_headers(message)
    contents = parse_contents(message)
    return {'from': h_from,
            'to': to,
            'subject': subject,
            'contents': contents}


def parse_headers(message):
    h_from = re.findall(FROM_RE, message)[0]
    if h_from.startswith('=?'):
        decoded, add = parse_encoded_header(h_from, RE_ENCODED)
        h_from = f'{decoded} {add[-1]}'
    to = re.findall(TO_RE, message)[0]
    if to.startswith('=?'):
        decoded, add = parse_encoded_header(to, RE_ENCODED)
        to = f'{decoded} {add[-1]}'
    subject = re.findall(SUBJECT_RE, message)
    subject = parse_encoded_subject(subject)
    return h_from, to, subject


def make_printable_from_content(content):
    printable = ''
    content_type = content['type']
    encoding = content['encoding']
    if content_type.startswith('text'):
        content_save = content['content'].decode(encoding)
        if content_save.startswith('<div>'):
            content_save = re.findall('<div>(.*?)</div>', content_save)[0]
        printable += f'\n\n{content_save}'
    elif content["filename"]:
        printable += f'\n\nФайл c именем {content["filename"]}.'
    return printable


def get_printable(parsed):
    printable = f'From: {parsed["from"]}\n' \
                f'To: {parsed["to"]}\n' \
                f'Subject: {parsed["subject"]}\n'
    for content in parsed['contents']:
        printable += make_printable_from_content(content)
    return printable
